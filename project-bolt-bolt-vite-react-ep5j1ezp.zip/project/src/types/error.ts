export interface ErrorMessage {
  message: string;
  code?: string;
  field?: string;
}

export type ErrorSeverity = 'error' | 'warning' | 'info';