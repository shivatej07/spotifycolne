export interface User {
  id: string;
  email: string;
  username: string;
  created_at: string;
}

export interface Song {
  id: string;
  title: string;
  artist: string;
  album: string;
  cover_url: string;
  audio_url: string;
  duration: number;
}

export interface Playlist {
  id: string;
  name: string;
  user_id: string;
  songs: Song[];
  created_at: string;
}

export interface Artist {
  id: string;
  name: string;
  image_url: string;
  bio: string;
}