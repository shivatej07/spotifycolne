import { create } from 'zustand';
import { Song } from '../types';

interface PlayerState {
  currentSong: Song | null;
  isPlaying: boolean;
  volume: number;
  queue: Song[];
  setCurrentSong: (song: Song) => void;
  togglePlay: () => void;
  setVolume: (volume: number) => void;
  addToQueue: (song: Song) => void;
  playNext: () => void;
  playPrevious: () => void;
}

export const usePlayerStore = create<PlayerState>((set, get) => ({
  currentSong: null,
  isPlaying: false,
  volume: 1,
  queue: [],
  
  setCurrentSong: (song) => set({ currentSong: song, isPlaying: true }),
  togglePlay: () => set((state) => ({ isPlaying: !state.isPlaying })),
  setVolume: (volume) => set({ volume }),
  
  addToQueue: (song) => set((state) => ({
    queue: [...state.queue, song]
  })),
  
  playNext: () => {
    const { queue, currentSong } = get();
    if (queue.length > 0) {
      const nextSong = queue[0];
      set({
        currentSong: nextSong,
        queue: queue.slice(1),
        isPlaying: true
      });
    }
  },
  
  playPrevious: () => {
    // Implementation for playing previous song
    // Would need to maintain a history of played songs
  }
}));