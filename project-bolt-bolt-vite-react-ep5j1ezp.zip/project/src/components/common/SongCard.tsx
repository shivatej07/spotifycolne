import React from 'react';
import { Play, Plus } from 'lucide-react';
import { Song } from '../../types';
import { usePlayerStore } from '../../store/playerStore';

interface SongCardProps {
  song: Song;
}

const SongCard = ({ song }: SongCardProps) => {
  const { setCurrentSong } = usePlayerStore();

  return (
    <div className="group bg-background-elevated p-4 rounded-lg hover:bg-gray-800 transition-colors">
      <div className="relative">
        <img
          src={song.cover_url}
          alt={song.title}
          className="w-full aspect-square object-cover rounded-md mb-4"
        />
        <button
          onClick={() => setCurrentSong(song)}
          className="absolute bottom-4 right-2 bg-primary p-3 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity hover:scale-105 transform"
        >
          <Play className="w-6 h-6 text-black" fill="black" />
        </button>
      </div>
      
      <div className="flex items-start justify-between">
        <div>
          <h3 className="text-text-primary font-medium truncate">{song.title}</h3>
          <p className="text-text-secondary text-sm truncate">{song.artist}</p>
        </div>
        <button className="text-text-secondary hover:text-text-primary p-2">
          <Plus className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default SongCard;