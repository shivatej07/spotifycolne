import React from 'react';
import { AlertCircle, AlertTriangle, Info } from 'lucide-react';
import { ErrorSeverity } from '../../types/error';

interface ErrorDisplayProps {
  message: string;
  severity?: ErrorSeverity;
  field?: string;
}

const ErrorDisplay: React.FC<ErrorDisplayProps> = ({
  message,
  severity = 'error',
  field
}) => {
  const getIcon = () => {
    switch (severity) {
      case 'error':
        return <AlertCircle className="w-5 h-5 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case 'info':
        return <Info className="w-5 h-5 text-blue-500" />;
    }
  };

  const getContainerClass = () => {
    const baseClass = "flex items-center gap-2 p-4 rounded-md";
    switch (severity) {
      case 'error':
        return `${baseClass} bg-red-100 text-red-800`;
      case 'warning':
        return `${baseClass} bg-yellow-100 text-yellow-800`;
      case 'info':
        return `${baseClass} bg-blue-100 text-blue-800`;
    }
  };

  return (
    <div className={getContainerClass()}>
      {getIcon()}
      <div>
        {field && <span className="font-semibold">{field}: </span>}
        {message}
      </div>
    </div>
  );
};

export default ErrorDisplay;