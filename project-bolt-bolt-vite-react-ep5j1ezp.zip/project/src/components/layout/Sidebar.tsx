import React from 'react';
import Logo from './Logo';
import Navigation from './Navigation';
import PlaylistSection from './PlaylistSection';

const Sidebar = () => {
  return (
    <aside className="w-64 bg-background-elevated h-full fixed left-0 top-0 p-6">
      <Logo />
      <nav className="space-y-6">
        <Navigation />
        <PlaylistSection />
      </nav>
    </aside>
  );
};

export default Sidebar;