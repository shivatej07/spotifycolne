import React from 'react';
import { PlusSquare, Heart } from 'lucide-react';
import NavItem from './NavItem';

const PlaylistSection = () => {
  return (
    <div className="pt-6 border-t border-gray-800 space-y-2">
      <button className="flex items-center gap-4 text-text-secondary hover:text-text-primary transition-colors w-full">
        <PlusSquare className="w-6 h-6" />
        <span>Create Playlist</span>
      </button>
      <NavItem to="/liked" Icon={Heart} label="Liked Songs" />
    </div>
  );
};

export default PlaylistSection;