import React from 'react';
import { Music } from 'lucide-react';

const Logo = () => {
  return (
    <div className="flex items-center gap-2 mb-8">
      <Music className="w-8 h-8 text-primary" />
      <h1 className="text-2xl font-bold text-text-primary">MyTunes</h1>
    </div>
  );
};

export default Logo;