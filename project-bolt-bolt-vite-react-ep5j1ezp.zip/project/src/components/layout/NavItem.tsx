import React from 'react';
import { NavLink } from 'react-router-dom';
import { LucideIcon } from 'lucide-react';

interface NavItemProps {
  to: string;
  Icon: LucideIcon;
  label: string;
}

const NavItem = ({ to, Icon, label }: NavItemProps) => {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `flex items-center gap-4 text-text-${
          isActive ? 'primary' : 'secondary'
        } hover:text-text-primary transition-colors`
      }
    >
      <Icon className="w-6 h-6" />
      <span>{label}</span>
    </NavLink>
  );
};

export default NavItem;