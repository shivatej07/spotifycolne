import React from 'react';
import { Home, Search, Library } from 'lucide-react';
import NavItem from './NavItem';

const Navigation = () => {
  return (
    <div className="space-y-2">
      <NavItem to="/" Icon={Home} label="Home" />
      <NavItem to="/search" Icon={Search} label="Search" />
      <NavItem to="/library" Icon={Library} label="Your Library" />
    </div>
  );
};

export default Navigation;