import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import ErrorBoundary from './components/common/ErrorBoundary';
import Sidebar from './components/layout/Sidebar';
import MusicPlayer from './components/player/MusicPlayer';
import Home from './pages/Home';
import Search from './pages/Search';
import Library from './pages/Library';
import Login from './pages/Login';
import SignUp from './pages/SignUp';
import About from './pages/About';
import Artists from './pages/Artists';

function App() {
  return (
    <ErrorBoundary>
      <Router>
        <div className="bg-background min-h-screen text-text-primary">
          <Sidebar />
          <main className="ml-64 p-8 pb-32">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/search" element={<Search />} />
              <Route path="/library" element={<Library />} />
              <Route path="/about" element={<About />} />
              <Route path="/artists" element={<Artists />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<SignUp />} />
            </Routes>
          </main>
          <MusicPlayer />
        </div>
      </Router>
    </ErrorBoundary>
  );
}

export default App;