import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import ErrorDisplay from '../components/common/ErrorDisplay';
import { validateField } from '../utils/errorHandling';

const SignUp = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const emailError = validateField(formData.email, 'Email');
    const passwordError = validateField(formData.password, 'Password');
    const confirmError = validateField(formData.confirmPassword, 'Confirm Password');
    
    if (emailError || passwordError || confirmError) {
      setError(emailError?.message || passwordError?.message || confirmError?.message || 'Invalid form data');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    // TODO: Implement actual signup logic
    navigate('/');
  };

  return (
    <div className="max-w-md mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-center">Create an Account</h1>
      
      {error && <ErrorDisplay message={error} />}
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="email" className="block text-sm font-medium mb-2">
            Email
          </label>
          <input
            type="email"
            id="email"
            value={formData.email}
            onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
            className="w-full px-4 py-2 bg-background-elevated rounded focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        
        <div>
          <label htmlFor="password" className="block text-sm font-medium mb-2">
            Password
          </label>
          <input
            type="password"
            id="password"
            value={formData.password}
            onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
            className="w-full px-4 py-2 bg-background-elevated rounded focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        
        <div>
          <label htmlFor="confirmPassword" className="block text-sm font-medium mb-2">
            Confirm Password
          </label>
          <input
            type="password"
            id="confirmPassword"
            value={formData.confirmPassword}
            onChange={(e) => setFormData(prev => ({ ...prev, confirmPassword: e.target.value }))}
            className="w-full px-4 py-2 bg-background-elevated rounded focus:outline-none focus:ring-2 focus:ring-primary"
          />
        </div>
        
        <button
          type="submit"
          className="w-full bg-primary text-black font-semibold py-3 rounded-full hover:bg-primary-dark transition-colors"
        >
          Sign Up
        </button>
      </form>
    </div>
  );
};

export default SignUp;