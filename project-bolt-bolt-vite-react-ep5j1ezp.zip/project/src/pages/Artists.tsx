import React from 'react';

const Artists = () => {
  const artists = [
    {
      id: '1',
      name: 'Queen',
      image: 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=400&q=80',
      genres: ['Rock', 'Classic Rock'],
    },
    {
      id: '2',
      name: 'Pink Floyd',
      image: 'https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?w=400&q=80',
      genres: ['Progressive Rock', 'Psychedelic Rock'],
    },
    {
      id: '3',
      name: 'Led Zeppelin',
      image: 'https://images.unsplash.com/photo-1511735111819-9a3f7709049c?w=400&q=80',
      genres: ['Hard Rock', 'Blues Rock'],
    }
  ];

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Popular Artists</h1>
      
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {artists.map((artist) => (
          <div key={artist.id} className="group cursor-pointer">
            <div className="relative aspect-square mb-4">
              <img
                src={artist.image}
                alt={artist.name}
                className="w-full h-full object-cover rounded-full"
              />
              <div className="absolute inset-0 bg-black bg-opacity-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
            <h3 className="text-lg font-semibold text-center">{artist.name}</h3>
            <p className="text-text-secondary text-sm text-center">
              {artist.genres.join(' • ')}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Artists;