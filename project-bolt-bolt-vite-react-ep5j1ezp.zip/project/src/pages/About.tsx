import React from 'react';
import { Music, PlayCircle, Users, ListMusic } from 'lucide-react';

const About = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <section className="text-center space-y-4">
        <h1 className="text-4xl font-bold">About MyTunes</h1>
        <p className="text-text-secondary text-lg">
          Stream your favorite music and create custom playlists with MyTunes - your personal music companion.
        </p>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
        <FeatureCard
          icon={PlayCircle}
          title="Stream Music"
          description="Access millions of songs instantly and enjoy high-quality streaming."
        />
        <FeatureCard
          icon={ListMusic}
          title="Create Playlists"
          description="Organize your music with custom playlists for every mood and occasion."
        />
        <FeatureCard
          icon={Users}
          title="Follow Artists"
          description="Stay updated with your favorite artists and their latest releases."
        />
        <FeatureCard
          icon={Music}
          title="Discover Music"
          description="Find new music with personalized recommendations based on your taste."
        />
      </div>
    </div>
  );
};

interface FeatureCardProps {
  icon: React.ElementType;
  title: string;
  description: string;
}

const FeatureCard = ({ icon: Icon, title, description }: FeatureCardProps) => {
  return (
    <div className="bg-background-elevated p-6 rounded-lg">
      <Icon className="w-12 h-12 text-primary mb-4" />
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-text-secondary">{description}</p>
    </div>
  );
};

export default About;