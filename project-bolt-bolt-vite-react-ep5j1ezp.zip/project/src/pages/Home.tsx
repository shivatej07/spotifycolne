import React from 'react';
import SongCard from '../components/common/SongCard';

const MOCK_SONGS = [
  {
    id: '1',
    title: 'Bohemian Rhapsody',
    artist: 'Queen',
    album: 'A Night at the Opera',
    cover_url: 'https://images.unsplash.com/photo-1514924013411-cbf25faa35bb?w=400&q=80',
    audio_url: 'https://example.com/audio1.mp3',
    duration: 354
  },
  // Add more mock songs here
];

const Home = () => {
  return (
    <div className="space-y-8">
      <section>
        <h2 className="text-2xl font-bold mb-4">Trending Now</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {MOCK_SONGS.map(song => (
            <SongCard key={song.id} song={song} />
          ))}
        </div>
      </section>
      
      <section>
        <h2 className="text-2xl font-bold mb-4">New Releases</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {MOCK_SONGS.map(song => (
            <SongCard key={song.id} song={song} />
          ))}
        </div>
      </section>
      
      <section>
        <h2 className="text-2xl font-bold mb-4">Top Artists</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {/* Artist cards will go here */}
        </div>
      </section>
    </div>
  );
};

export default Home;