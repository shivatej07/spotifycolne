import { ErrorMessage } from '../types/error';

export const formatApiError = (error: unknown): ErrorMessage => {
  if (error instanceof Error) {
    return { message: error.message };
  }
  
  if (typeof error === 'string') {
    return { message: error };
  }
  
  return { message: 'An unexpected error occurred' };
};

export const validateField = (value: string, fieldName: string): ErrorMessage | null => {
  if (!value.trim()) {
    return {
      message: `${fieldName} is required`,
      field: fieldName
    };
  }
  return null;
};

export const handleAuthError = (error: unknown): ErrorMessage => {
  const baseError = formatApiError(error);
  
  // Add specific handling for authentication errors
  if (baseError.message.includes('auth')) {
    return {
      ...baseError,
      code: 'AUTH_ERROR'
    };
  }
  
  return baseError;
};